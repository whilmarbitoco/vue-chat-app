<template>
    <div class="footer">
        <p>2023 &copy; Alouh Sperk. All rights reserved.</p>
    </div>
</template>

<script>
export default {
    name: "Footer",
};
</script>

<style>
.footer {
    margin: 0 auto;
    width: 100vw;
    height: 10vh;
    position: fixed;
}

.footer p {
    text-align: center;
}
</style>
