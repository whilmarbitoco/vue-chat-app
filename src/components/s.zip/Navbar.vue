<template>
    <header>
        <h2>Chat App</h2>
    </header>
</template>

<script>
export default {
    name: "Navbar",
};
</script>

<style>
header {
    padding: 0.5rem 10px;
    background: var(--thirdColor);
    box-shadow: 0 4px 30px rgba(0, 0, 0, 0.1);
}
</style>
