<template>
    <div class="main">
        <Header />
        <Chats :chats="chats" :receive="receive" />
        <Form @message-sent="sendMessage" />
        <Footer />
    </div>
</template>

<script>
import Header from "./components/Header.vue";
import Chats from "./components/Chats.vue";
import Form from "./components/Form.vue";
import Footer from "./components/Footer.vue";

export default {
    name: "App",
    components: {
        Header,
        Chats,
        Form,
        Footer,
    },
    data() {
        return {
            chats: [],
            receive: [],
            state: false,
        };
    },
    methods: {
        sendMessage(e, chats) {
            e.preventDefault();
            if (chats) {
                const newChat = {
                    id: Math.floor((Math.random() * 19244727) / 10),
                    msg: message,
                };
                this.chats.push(newChat);
                this.state = true;
            }
        },
    },
};
</script>
